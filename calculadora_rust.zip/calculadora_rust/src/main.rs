use std::io;

fn main() {
    println!("==============================");
    println!("     CALCULADORA EN RUST      ");
    println!("==============================");

    // Lee el primer numero
    println!("Ingrese el primer número:");
    let mut input1 = String::new();
    io::stdin().read_line(&mut input1).expect("Error al leer la entrada");
    let num1: f64 = match input1.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Error: Debe ingresar un número válido.");
            return;
        }
    };

    // Lee el operador
    println!("Ingrese la operación (+, -, *, /):");
    let mut operator = String::new();
    io::stdin().read_line(&mut operator).expect("Error al leer la entrada");
    let operator = operator.trim();

    // LLee el segundo numero
    println!("Ingrese el segundo número:");
    let mut input2 = String::new();
    io::stdin().read_line(&mut input2).expect("Error al leer la entrada");
    let num2: f64 = match input2.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Error: Debe ingresar un número válido.");
            return;
        }
    };

    // Realiza la operación segun lo seleccionado
    let resultado = match operator {
        "+" => num1 + num2,
        "-" => num1 - num2,
        "*" => num1 * num2,
        "/" => {
            if num2 == 0.0 {
                println!("Error: No se puede dividir entre cero.");
                return;
            }
            num1 / num2
        }
        _ => {
            println!("Error: Operador no válido. Use +, -, * o /");
            return;
        }
    };

    // Muestra el resultado final
    println!("------------------------------");
    println!("Resultado: {} {} {} = {}", num1, operator, num2, resultado);
    println!("------------------------------");
}
