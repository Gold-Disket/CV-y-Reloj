/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Logic;

import GUI.Window;

/**
 *
 * @author mechanical-radio
 */
public class Conversor_Pixeles_Grises {

    public static void main(String[] args) {
        Window windows = new Window();
        windows.setVisible(true);
    }
}
